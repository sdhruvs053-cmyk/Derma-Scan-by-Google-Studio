/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence, MotionConfig } from 'motion/react';
import { 
  RotateCcw,
  RefreshCcw,
  Camera, 
  History, 
  User, 
  Bot, 
  Droplet, 
  Sparkles, 
  ShieldAlert,
  Search,
  LayoutDashboard,
  Menu,
  X,
  ChevronRight,
  ShieldCheck,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Download,
  FileUp,
  BarChart3,
  ClipboardList
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Toaster } from '@/components/ui/sonner';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useUserStore } from '@/lib/store';
import { analyzeSkin, analyzeIngredients } from '@/lib/gemini';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { auth, login, logout } from '@/lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserScans, saveScan } from '@/lib/firestoreService';
import { ChatAssistant } from '@/components/chat/ChatAssistant';
import { ProductAnalyzer } from '@/components/products/ProductAnalyzer';
import { SkinRadar } from '@/components/analysis/SkinRadar';
import { FaceScanner } from '@/components/analysis/FaceScanner';
import { SkinAgeAnalysis } from '@/components/analysis/SkinAgeAnalysis';
import { BiometricFacialMesh } from '@/components/analysis/BiometricFacialMesh';
import { cn } from '@/lib/utils';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// --- Utilities ---

function dataURLtoFile(dataurl: string, filename: string) {
  const arr = dataurl.split(',');
  const mime = arr[0].match(/:(.*?);/)?.[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

async function compressImage(dataUrl: string, maxWidth = 800, quality = 0.7): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => resolve(dataUrl); // Fallback to original if compression fails
  });
}

// --- Optical Components ---

function MultiSpectralView({ imageUrl, concerns, showHotspots, faceMesh }: { imageUrl: string; concerns: any[]; showHotspots: boolean; faceMesh?: any[] }) {
  const [selectedView, setSelectedView] = useState(0);
  const [selectedConcern, setSelectedConcern] = useState<any>(null);

  // Memoize fallback mesh points to prevent jitter
  const fallbackMesh = useMemo(() => {
    return Array.from({ length: 468 }).map(() => ({
      x: 10 + Math.random() * 80,
      y: 10 + Math.random() * 80
    }));
  }, []);

  const views = [
    { 
      name: "Standard VIS", 
      filter: "none", 
      label: "VISUAL",
      explanation: "Full-spectrum mapping of visible surface anomalies. Used for baseline structural reference and texture profiling.",
      focus: "Surface Texture",
      data: { wavelength: "400-700nm", depth: "Stratum Corneum" }
    },
    { 
      name: "UV Mapping", 
      filter: "grayscale(100%) contrast(140%) brightness(1.2) invert(0.05)", 
      label: "UV_RAD",
      explanation: "Highlights deep dermal damage and underlying sun exposure indicators often invisible to the naked eye.",
      focus: "Photo-Damage",
      data: { wavelength: "320-400nm", depth: "Epidermis" }
    },
    { 
      name: "Pigment Map", 
      filter: "sepia(80%) contrast(120%) brightness(1.1)", 
      label: "HYPER_P",
      explanation: "Isolates melanin distribution to identify hyperpigmentation clusters, melasma, and uneven tone regions.",
      focus: "Melanin Density",
      data: { wavelength: "550nm", depth: "Basal Layer" }
    },
    { 
      name: "Vascular Scan", 
      filter: "hue-rotate(-15deg) saturate(250%) contrast(110%)", 
      label: "VASCULAR",
      explanation: "Enhances hemoglobin visibility to detect inflammation, sensitivity zones, and sub-surface broken capillaries.",
      focus: "Redness & Flow",
      data: { wavelength: "540-580nm", depth: "Dermis" }
    },
    { 
      name: "Thermal Bio", 
      filter: "hue-rotate(190deg) saturate(180%) brightness(1.2)", 
      label: "BIO_HEAT",
      explanation: "Simulates thermal signature mapping to identify active inflammatory responses and metabolic hotspots.",
      focus: "Active Acne",
      data: { wavelength: "IR-1200nm", depth: "Subcutaneous" }
    },
    { 
      name: "Pore Depth", 
      filter: "grayscale(100%) brightness(1.1) contrast(1.4) saturate(0%)", 
      label: "INTERNAL",
      explanation: "Mathematical contrast enhancement to map pore dilation, surface elasticity, and follicular congestion.",
      focus: "Pore Topology",
      data: { wavelength: "LOG-DIFF", depth: "Pore Exit" }
    },
  ];

  const currentView = views[selectedView];

  return (
    <div className="space-y-12">
      {/* View Selector Tabs - Futuristic Pill Style */}
      <div className="flex flex-wrap items-center justify-center gap-4 px-2">
        {views.map((view, i) => (
          <button 
            key={i} 
            onClick={() => setSelectedView(i)}
            className={cn(
              "group relative overflow-hidden transition-all duration-700 h-14 min-w-[140px] px-6",
              selectedView === i 
                ? "bg-slate-900 rounded-2xl shadow-xl shadow-teal-500/10 scale-105" 
                : "bg-white/50 backdrop-blur-sm border border-slate-100 rounded-xl hover:bg-slate-50"
            )}
          >
             <div className="flex flex-col items-start gap-0.5 relative z-10 text-left">
                <span className={cn(
                  "text-[7px] font-mono font-black uppercase tracking-[0.3em]",
                  selectedView === i ? "text-primary" : "text-slate-400"
                )}>{view.label}</span>
                <span className={cn(
                  "text-[10px] font-serif italic font-black uppercase tracking-tight",
                  selectedView === i ? "text-white" : "text-slate-900"
                )}>{view.name}</span>
             </div>
             {selectedView === i && (
                <motion.div 
                  layoutId="tab-highlight"
                  className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none"
                />
             )}
          </button>
        ))}
      </div>

      {/* Main Scanner Visual Interface */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
        <div className="xl:col-span-8 relative aspect-[9/16] max-h-[85vh] mx-auto rounded-[2.5rem] md:rounded-[4rem] overflow-hidden border-[4px] md:border-[8px] border-white shadow-2xl glass-card group bg-black flex items-center justify-center">
           <img 
             src={imageUrl} 
             alt="Synthetic Analysis" 
             className="w-full h-full object-cover transition-all duration-1000 ease-in-out"
             style={{ filter: currentView.filter }}
             referrerPolicy="no-referrer"
           />
           <div className="absolute inset-0 bg-primary/5 mix-blend-overlay pointer-events-none"></div>
           
           {/* HUD UI Elements */}
           <div className="absolute inset-[4%] md:inset-10 border border-white/20 rounded-[1.5rem] md:rounded-[3rem] pointer-events-none"></div>
           
           {/* Corner Technical Markers */}
           <div className="absolute top-[4%] left-[4%] md:top-12 md:left-12 w-16 h-16 md:w-32 md:h-32 border-t-2 border-l-2 border-primary/40 rounded-tl-[1rem] md:rounded-tl-[2rem] pointer-events-none"></div>
           <div className="absolute top-[4%] right-[4%] md:top-12 md:right-12 w-16 h-16 md:w-32 md:h-32 border-t-2 border-r-2 border-primary/40 rounded-tr-[1rem] md:rounded-tr-[2rem] pointer-events-none"></div>
           <div className="absolute bottom-[4%] left-[4%] md:bottom-12 md:left-12 w-16 h-16 md:w-32 md:h-32 border-b-2 border-l-2 border-primary/40 rounded-bl-[1rem] md:rounded-bl-[2rem] pointer-events-none"></div>
           <div className="absolute bottom-[4%] right-[4%] md:bottom-12 md:right-12 w-16 h-16 md:w-32 md:h-32 border-b-2 border-r-2 border-primary/40 rounded-br-[1rem] md:rounded-br-[2rem] pointer-events-none"></div>

           {/* Live HUD Data Stats */}
           <div className="absolute top-[8%] left-[8%] md:top-16 md:left-16 space-y-2 md:space-y-4 pointer-events-none">
              <div className="flex flex-col gap-0.5 md:gap-1">
                 <span className="text-[6px] md:text-[7px] font-mono font-black text-primary uppercase tracking-[0.4em]">SYNC_MODE</span>
                 <span className="text-[8px] md:text-[10px] font-mono font-bold text-white uppercase tracking-widest bg-black/40 px-2 py-0.5 md:px-3 md:py-1 rounded-full backdrop-blur-md border border-white/10">REALTIME_V4_LAB</span>
              </div>
              <div className="flex flex-col gap-0.5 md:gap-1">
                 <span className="text-[6px] md:text-[7px] font-mono font-black text-primary uppercase tracking-[0.4em]">FILTER_PARAM</span>
                 <span className="text-[8px] md:text-[10px] font-mono font-bold text-white uppercase tracking-widest">{currentView.data.wavelength}</span>
              </div>
           </div>

           {/* Circular Tech HUD Overlay (Animated) */}
           <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden opacity-20">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                className="w-[80%] aspect-square border border-dashed border-white/30 rounded-full"
              />
              <motion.div 
                animate={{ rotate: -360 }}
                transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
                className="absolute w-[60%] aspect-square border border-white/10 rounded-full"
              />
           </div>

           {/* Advanced Biometric Overlay */}
           <BiometricFacialMesh 
              landmarks={faceMesh || null} 
              concerns={concerns} 
              showHotspots={showHotspots} 
              selectedView={selectedView}
           />

           {/* Interactive UI Pins */}
           <AnimatePresence>
             {showHotspots && concerns.map((c, i) => c.coordinates && (
               <motion.div
                 key={i}
                 initial={{ scale: 0, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 exit={{ scale: 0, opacity: 0 }}
                 className="absolute w-8 h-8 -ml-4 -mt-4 flex items-center justify-center cursor-pointer z-30"
                 style={{ left: `${c.coordinates.x}%`, top: `${c.coordinates.y}%` }}
                 onClick={() => setSelectedConcern(selectedConcern === c ? null : c)}
               >
                  <div className={cn(
                    "absolute inset-0 rounded-full animate-ping opacity-30",
                    c.type.toLowerCase().includes('acne') ? "bg-rose-500" : "bg-primary"
                  )}></div>
                  <div className={cn(
                    "w-3 h-3 rounded-full border-2 border-white transition-all duration-300 shadow-xl",
                    selectedConcern === c ? "scale-150 ring-4 ring-white/20" : "hover:scale-125",
                    c.type.toLowerCase().includes('acne') ? "bg-rose-500" : "bg-primary"
                  )}></div>
               </motion.div>
             ))}
           </AnimatePresence>

           {/* View Label Bottom - HUD Style */}
           <div className="absolute bottom-16 left-16 right-16 flex justify-between items-end">
              <div className="space-y-1">
                 <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono font-black text-white/40 tracking-[0.4em] uppercase">Phase_Calibration</span>
                    <div className="h-0.5 w-12 bg-primary/60"></div>
                 </div>
                 <h4 className="text-5xl font-serif font-black text-white italic tracking-tighter uppercase leading-none drop-shadow-lg">{currentView.name}</h4>
              </div>
              <div className="flex flex-col items-end gap-2">
                 <div className="glass-card px-3 md:px-5 py-1 md:py-2 rounded-xl md:rounded-2xl border-white/20 text-white/90">
                    <span className="text-[6px] md:text-[7px] font-mono font-black uppercase tracking-[0.2em] block mb-0.5 md:mb-1">Target Mapping</span>
                    <span className="text-[9px] md:text-[11px] font-serif italic font-black uppercase tracking-tight">{currentView.focus}</span>
                 </div>
              </div>
           </div>
        </div>

        {/* Diagnostic Sidebar Overhaul */}
        <div className="xl:col-span-4 flex flex-col justify-between space-y-8">
           <Card className="rounded-[3.5rem] glass-card border-white/40 shadow-xl p-10 space-y-10 border-l-4 border-l-primary/40 h-full">
              <div className="space-y-6">
                 <div className="flex items-center justify-between">
                    <div className="w-14 h-14 bg-slate-900 rounded-[1.5rem] flex items-center justify-center shadow-lg">
                       <Sparkles className="w-6 h-6 text-primary" />
                    </div>
                    <Badge variant="ghost" className="font-mono text-[8px] uppercase tracking-widest text-primary font-black border border-primary/20">BIO_LINK_READY</Badge>
                 </div>
                 <div className="space-y-2">
                    <h5 className="text-4xl font-serif font-black italic text-slate-900 tracking-tighter uppercase">Lab Diagnostics</h5>
                    <p className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest">Spectral Identification v4.2</p>
                 </div>
                 
                 <div className="bg-slate-50/80 p-8 rounded-[2.5rem] border border-slate-100">
                    <p className="text-slate-600 font-medium leading-relaxed italic text-base">
                      "{currentView.explanation}"
                    </p>
                 </div>
              </div>

              <div className="space-y-8">
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                       <span className="text-[8px] font-mono font-black text-slate-400 uppercase tracking-widest">WAVELENGTH</span>
                       <div className="bg-white px-4 py-2 rounded-xl border border-slate-100 text-[10px] font-bold text-slate-900 font-mono italic">{currentView.data.wavelength}</div>
                    </div>
                    <div className="space-y-1.5">
                       <span className="text-[8px] font-mono font-black text-slate-400 uppercase tracking-widest">TARGET_DEPTH</span>
                       <div className="bg-white px-4 py-2 rounded-xl border border-slate-100 text-[10px] font-bold text-slate-900 font-mono italic uppercase">{currentView.data.depth}</div>
                    </div>
                 </div>

                 <div className="space-y-3 pt-6 border-t border-slate-100/50">
                    <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 font-black uppercase tracking-widest">
                       <span>Synthesis Confidence</span>
                       <span className="text-primary">99.4%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100/50 rounded-full overflow-hidden shadow-inner border border-white">
                       <motion.div 
                         initial={{ width: 0 }}
                         animate={{ width: "99.4%" }}
                         transition={{ duration: 1.5, ease: "easeOut" }}
                         className="h-full bg-primary shadow-[0_0_10px_rgba(13,148,136,0.3)]"
                       />
                    </div>
                 </div>
              </div>
           </Card>

           <div className="glass-card rounded-full p-2 pl-3 flex items-center justify-between border-white/40 shadow-lg">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-primary" />
                 </div>
                 <div className="flex flex-col">
                    <span className="text-[7px] font-mono font-black text-slate-400 uppercase tracking-widest">SYSTEM_CALIBRATED</span>
                    <span className="text-[9px] font-black text-slate-900 uppercase italic">Standards Verified</span>
                 </div>
              </div>
              <Button size="sm" className="rounded-full bg-slate-900 text-white h-10 px-8 font-mono font-black text-[9px] tracking-widest shadow-lg">CALIBRATE_AUTO</Button>
           </div>
        </div>
      </div>
    </div>
  );
}

// --- Layouts ---

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastImageUrl, setLastImageUrl] = useState<string | null>(null);
  const [showHotspots, setShowHotspots] = useState(true);
  const [isExporting, setIsExporting] = useState(false);

  const handleReset = () => {
    if (confirm("Reset all analysis data? This will clear your local history.")) {
      clearHistory();
      setLastImageUrl(null);
      setActiveTab('home');
      toast.success("System reset successful. All local session data purged.");
    }
  };
  const { user, scans, setUser, setScans, clearHistory } = useUserStore();
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      try {
        if (fbUser) {
          setUser({
            uid: fbUser.uid,
            name: fbUser.displayName || 'Guest',
            email: fbUser.email || '',
            skinType: 'Normal',
            concerns: []
          });
          const history = await getUserScans();
          if (history) setScans(history);
        } else {
          setUser(null);
          clearHistory();
        }
      } catch (err) {
        console.error("Initialization error:", err);
      } finally {
        setIsInitializing(false);
      }
    });

    return () => unsubscribe();
  }, [setUser, setScans, clearHistory]);

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center space-y-8">
         <div className="w-16 h-16 border-4 border-primary/10 border-t-primary rounded-full animate-spin" />
         <div className="space-y-2 text-center">
            <h1 className="text-2xl font-serif font-black italic clinical-gradient-text uppercase tracking-tighter">Aluune</h1>
            <p className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-[0.4em]">Establishing Neural Link...</p>
         </div>
      </div>
    );
  }

  const latestScan = scans[0];

  const handleScan = async (file: File, faceMesh?: any[]) => {
    if (!user) {
      toast.error("Please sign in to save results and track progress.");
      handleAuth();
      return;
    }

    setIsAnalyzing(true);
    const toastId = toast.loading("Analyzing your skin biopsy...");
    
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const originalBase64 = reader.result as string;
        const compressedBase64 = await compressImage(originalBase64);
        setLastImageUrl(compressedBase64);
        const result = await analyzeSkin(compressedBase64);
        
        const finalResult = { ...result, faceMesh, imageUrl: compressedBase64 };
        await saveScan(finalResult);
        const history = await getUserScans();
        if (history) setScans(history);
        
        toast.success("Analysis complete!", { id: toastId });
        setActiveTab('dashboard');
      };
    } catch (error) {
      toast.error("Analysis failed. Please try again.", { id: toastId });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const downloadReport = async () => {
    if (!latestScan) return;
    setIsExporting(true);
    const toastId = toast.loading("Generating clinical PDF report...");

    try {
      const element = document.getElementById('biometric-report');
      if (!element) throw new Error("Report element not found");

      const canvas = await html2canvas(element, {
        backgroundColor: '#ffffff',
        scale: 3,
        useCORS: true,
        logging: false,
        ignoreElements: (element) => element.classList.contains('no-print'),
        windowWidth: 1200, // Ensure fixed width for better layout consistency in PDF
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`DERMASync_Report_${new Date().getTime()}.pdf`);
      
      toast.success("Report downloaded!", { id: toastId });
    } catch (error) {
      console.error(error);
      toast.error("Failed to generate PDF.", { id: toastId });
    } finally {
      setIsExporting(false);
    }
  };

  const handleAuth = async () => {
    try {
      if (user) {
        await logout();
        toast.success("Signed out successfully");
      } else {
        await login();
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-blocked') {
        toast.error("Sign-in popup was blocked.", {
          description: "Please enable popups for this site or try opening the app in a new tab.",
          duration: 6000,
          action: {
            label: "Open App",
            onClick: () => window.open(window.location.href, '_blank')
          }
        });
      } else if (err.code === 'auth/cancelled-popup-request') {
        toast.error("Authentication in progress", {
          description: "A previous sign-in attempt is still active. Please wait or refresh.",
        });
      } else {
        toast.error("Authentication failed", {
          description: "Ensure the current domain is authorized in Firebase Console (Authentication > Settings > Authorized domains)."
        });
      }
    }
  };

  return (
    <MotionConfig transition={{ type: "spring", bounce: 0, duration: 0.4, colorSpace: "rgb" } as any}>
      <div className="min-h-screen font-sans bg-background relative overflow-x-hidden selection:bg-teal-50">
      <Toaster position="top-center" theme="light" />

      {/* Background HUD Grid */}
      <div className="absolute inset-0 medical-grid opacity-20 pointer-events-none"></div>
      
      {/* Dynamic Data Waves (Subtle) */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none overflow-hidden">
         <motion.svg 
           animate={{ x: [-100, 0] }}
           transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
           className="w-[200%] h-full" viewBox="0 0 200 100"
         >
            <path d="M0,50 Q25,30 50,50 T100,50 T150,50 T200,50" fill="none" stroke="currentColor" strokeWidth="0.2" className="text-teal-600" />
            <path d="M0,60 Q25,80 50,60 T100,60 T150,60 T200,60" fill="none" stroke="currentColor" strokeWidth="0.2" className="text-cyan-600" />
         </motion.svg>
      </div>

      {/* Persistent Navigation */}
      <nav className="fixed top-0 inset-x-0 z-50 glass-card mx-6 my-6 rounded-[2.5rem] shadow-xl border-white/40">
        <div className="max-w-7xl mx-auto px-8 h-12 flex items-center justify-between">
          <div className="flex items-center gap-4 cursor-pointer group" onClick={() => setActiveTab('home')}>
            <div className="w-8 h-8 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/20 group-hover:scale-110 transition-transform">
              <Sparkles className="w-4 h-4 text-primary" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-serif font-black tracking-tighter uppercase italic leading-none clinical-gradient-text drop-shadow-sm">Aluune</h1>
              <span className="text-[7px] font-mono font-bold text-slate-400 tracking-[0.3em] uppercase mt-0.5">Bio-Digital Skin Lab</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-10">
            {[
              { id: 'dashboard', label: 'Monitor' },
              { id: 'analyze', label: 'Scanner' },
              { id: 'products', label: 'Laboratory' },
              { id: 'assistant', label: 'Advisory' }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "text-[9px] font-mono font-black uppercase tracking-[0.3em] transition-all hover:text-primary px-3 py-1 relative",
                  activeTab === tab.id ? "text-primary" : "text-slate-400"
                )}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div layoutId="nav-pill" className="absolute -bottom-1 inset-x-0 h-0.5 bg-primary rounded-full shadow-[0_0_8px_rgba(13,148,136,0.3)]" />
                )}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-6">
            {user ? (
              <div className="flex items-center gap-3 bg-slate-50/50 pl-4 py-1 pr-1 rounded-full border border-slate-100">
                <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">{user.name}</span>
                <div 
                  className="w-8 h-8 rounded-full border border-white bg-white shadow-sm flex items-center justify-center cursor-pointer hover:ring-2 hover:ring-primary/20 transition-all overflow-hidden"
                  onClick={handleAuth}
                >
                  <div className="w-full h-full bg-teal-50 flex items-center justify-center text-[9px] font-black text-primary">
                    {user.name.substring(0, 2).toUpperCase()}
                  </div>
                </div>
              </div>
            ) : (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleAuth} 
                className="hidden sm:flex rounded-full text-slate-500 hover:text-primary hover:bg-teal-50 transition-all font-mono font-black text-[9px] tracking-widest"
              >
                ACCESS_TERMINAL
              </Button>
            )}
            <Button 
              size="sm" 
              className="bg-primary hover:bg-primary/90 text-white rounded-full px-6 font-mono font-black text-[9px] tracking-[0.2em] shadow-lg shadow-primary/20 h-8" 
              onClick={() => setActiveTab('analyze')}
            >
              INITIATE_SCAN
            </Button>
          </div>
        </div>
      </nav>

      <main className="pt-24 sm:pt-32 pb-24 sm:pb-32 max-w-screen-xl mx-auto px-4 sm:px-8 relative z-10">
        {activeTab === 'home' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center text-center space-y-20"
          >
            <div className="space-y-8 max-w-4xl">
              <Badge variant="outline" className="px-5 py-1.5 rounded-full bg-emerald-50 text-emerald-600 font-mono text-[10px] tracking-widest border-emerald-600/20 flex items-center gap-2 w-fit mx-auto">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_#10b981]"></span>
                V4.0 GENERATIVE DERMATOLOGY ENGINE
              </Badge>
              <h1 className="text-7xl md:text-9xl font-serif font-black tracking-tighter leading-[0.8] text-slate-900">
                 Precision.<br/>Digital Bio.
              </h1>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
                Experience clinical-grade biometric scanning. Move beyond guesswork with ultra-fine mapping and ingredient-level intelligence.
              </p>
              
              <div className="flex flex-wrap items-center justify-center gap-6 pt-4">
                 <Button 
                   size="lg" 
                   onClick={() => setActiveTab('analyze')}
                   className="h-16 px-12 rounded-full bg-primary hover:bg-primary/90 text-white font-mono font-black tracking-[0.2em] text-xs shadow-2xl shadow-primary/30 group"
                 >
                    <Camera className="w-5 h-5 mr-4 group-hover:rotate-12 transition-transform" />
                    START_SCAN
                 </Button>
                 <Button 
                   variant="outline" 
                   size="lg" 
                   onClick={() => setActiveTab('dashboard')}
                   className="h-16 px-12 rounded-full glass-card text-primary border-primary/10 font-mono font-black tracking-[0.2em] text-xs hover:bg-teal-50"
                 >
                    <LayoutDashboard className="w-5 h-5 mr-4" />
                    MONITOR_HUB
                 </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-12 w-full max-w-5xl">
               {[
                 { label: "Sync_Rate", val: "99.98%", sub: "ISO-204" },
                 { label: "AI_Confidence", val: "94.2%", sub: "Dermal_V4" },
                 { label: "Processing", val: "1.2ms", sub: "Neural_Link" },
                 { label: "Database", val: "4.2M+", sub: "Indexed_Bio" }
               ].map((stat, i) => (
                 <motion.div 
                   key={i}
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   transition={{ delay: 0.5 + (i * 0.1) }}
                   className="text-left space-y-1 relative"
                 >
                    <div className="absolute -left-4 top-0 bottom-0 w-[1px] bg-primary/10"></div>
                    <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">{stat.label}</p>
                    <p className="text-4xl font-serif font-black italic text-slate-900 tracking-tighter">{stat.val}</p>
                    <p className="text-[7px] font-mono text-primary/60 uppercase tracking-[0.3em] font-bold">{stat.sub}</p>
                 </motion.div>
               ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'analyze' && (
          <div className="max-w-3xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="text-center space-y-4">
              <h2 className="text-5xl font-serif font-black tracking-tight text-slate-900 italic">Biometric Scan</h2>
              <p className="text-slate-500 max-w-sm mx-auto leading-relaxed font-medium">
                Initialize optical sensors. Ensure direct illumination for 99.4% confidence calibration.
              </p>
            </div>
            
            <div className="p-1 bg-white border border-slate-200 rounded-[3.5rem] relative shadow-xl">
              <Card className="border-none bg-slate-50 rounded-[3rem] overflow-hidden min-h-[600px] md:min-h-0 md:aspect-[4/5] relative group transition-all">
                {!user ? (
                  <div className="h-full flex flex-col items-center justify-center p-12 space-y-8">
                    <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center">
                       <ShieldAlert className="w-10 h-10 text-emerald-600" />
                    </div>
                    <div className="text-center space-y-2">
                       <h3 className="text-2xl font-black text-slate-900">ACCESS RESTRICTED</h3>
                       <p className="text-slate-500 text-sm max-w-xs">Biometric data processing requires an encrypted session link.</p>
                    </div>
                    <Button onClick={handleAuth} className="rounded-2xl h-14 px-8 bg-emerald-600 text-white hover:bg-emerald-700 font-black tracking-tight shadow-lg shadow-emerald-600/20">
                       ESTABLISH CONNECTION
                    </Button>
                  </div>
                ) : (
                  <FaceScanner 
                    isAnalyzing={isAnalyzing} 
                    onCapture={(img, mesh) => {
                      const file = dataURLtoFile(img, "capture.jpg");
                      handleScan(file, mesh || undefined);
                    }} 
                  />
                )}
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-white/95 backdrop-blur-3xl z-20 flex flex-col items-center justify-center space-y-8">
                    <div className="relative w-40 h-40">
                      <svg className="w-full h-full -rotate-90">
                        <circle cx="80" cy="80" r="75" fill="none" stroke="rgba(0,0,0,0.05)" strokeWidth="4"/>
                        <motion.circle 
                          cx="80" cy="80" r="75" 
                          fill="none" 
                          stroke="#10b981" 
                          strokeWidth="6"
                          strokeDasharray="471"
                          animate={{ strokeDashoffset: [471, 0], rotate: 360 }}
                          transition={{ 
                            strokeDashoffset: { duration: 2, repeat: Infinity, ease: "easeInOut" },
                            rotate: { duration: 4, repeat: Infinity, ease: "linear" }
                          }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                         <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center animate-ping">
                            <div className="w-4 h-4 bg-emerald-600 rounded-full shadow-[0_0_15px_#10b981]"></div>
                         </div>
                      </div>
                    </div>
                    <div className="text-center space-y-2">
                      <p className="font-black text-2xl text-slate-900 tracking-widest uppercase italic">Analyzing Dermal Layer</p>
                      <p className="text-[10px] text-sky-600 font-mono uppercase tracking-[0.4em] animate-pulse">Scanning 18,500 Biometric Points</p>
                    </div>
                  </div>
                )}
              </Card>
            </div>

            <div className="flex gap-5 p-6 bg-emerald-50/50 border border-emerald-100 rounded-[2.5rem]">
              <div className="w-10 h-10 rounded-2xl bg-white border border-emerald-100 flex items-center justify-center shrink-0 shadow-sm">
                <AlertCircle className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-900 uppercase tracking-wider italic">Calibration Note</p>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  Analysis is restricted to educational biometrics. Precision is based on current environmental luminosity. 
                  <span className="text-emerald-600 ml-1 font-black underline underline-offset-4 decoration-emerald-100">Always proceed with clinical validation for medical anomalies.</span>
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="space-y-12 animate-in fade-in duration-1000">
            {!latestScan ? (
              <div className="flex flex-col items-center text-center py-40 space-y-12">
                <div className="relative">
                  <div className="absolute -inset-24 bg-teal-50 rounded-full blur-[120px] opacity-60"></div>
                  <div className="relative w-32 h-32 bg-white border border-slate-100 rounded-full flex items-center justify-center shadow-2xl">
                    <div className="absolute inset-0 border-2 border-dashed border-teal-200/50 rounded-full animate-[spin_20s_linear_infinite]"></div>
                    <TrendingUp className="w-12 h-12 text-slate-200" />
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="text-5xl font-serif font-black tracking-tight text-slate-900 leading-tight uppercase italic">Archive Null.</h3>
                  <p className="text-slate-400 max-w-sm mx-auto leading-relaxed font-mono font-bold text-[10px] uppercase tracking-widest">
                    SYSTEM READY: INITIALIZE DERMAL SEQUENCE TO COMMENCE MONITORING.
                  </p>
                </div>
                <Button onClick={() => setActiveTab('analyze')} className="h-16 px-16 rounded-full bg-primary hover:bg-primary/90 text-white font-mono font-black text-xs tracking-[0.2em] shadow-2xl shadow-primary/30 transition-all hover:scale-105">
                   INITIATE_FIRST_SCAN
                </Button>
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 lg:gap-12"
                id="biometric-report"
              >
                {/* Header Info Block */}
                <div className="lg:col-span-12 flex flex-col md:flex-row md:items-end justify-between px-4 sm:px-8 gap-8 border-l-2 border-primary/20">
                   <div className="space-y-4">
                     <div className="flex flex-wrap gap-4 sm:gap-8 text-[9px] font-mono font-black text-slate-400 uppercase tracking-[0.3em]">
                        <div className="flex gap-2"><span>PATIENT:</span> <span className="text-primary">{user?.name}</span></div>
                        <div className="flex gap-2"><span>LEVEL:</span> <span className="text-primary">BIO_VERIFIED</span></div>
                        <div className="flex gap-2"><span>REF:</span> <span className="text-primary tracking-tighter">IDX-{Math.floor(Math.random()*10000)}</span></div>
                     </div>
                     <h2 className="text-[clamp(1.5rem,6vw,3.75rem)] font-serif font-black tracking-tighter text-slate-900 italic uppercase clinical-gradient-text leading-[0.9] border-b-4 border-primary/10 pb-4">Diagnostic Report</h2>
                     <div className="flex items-center gap-4">
                        <div className="h-0.5 w-12 bg-primary/30"></div>
                        <p className="text-[10px] text-slate-400 font-mono uppercase tracking-[0.4em] font-black">Neural_Synthesis_v4.2.0.8</p>
                     </div>
                   </div>
                   <div className="flex flex-wrap items-center gap-4 no-print">
                      <Button 
                        variant="outline"
                        size="sm" 
                        onClick={() => {
                          setLastImageUrl(null);
                          setActiveTab('analyze');
                        }}
                        className="rounded-full px-8 glass-card border-slate-200 text-slate-900 hover:bg-slate-50 font-mono font-black text-[9px] tracking-widest flex items-center gap-2 h-10"
                      >
                        <RefreshCcw className="w-3.5 h-3.5" />
                        RE-SCAN
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={downloadReport}
                        disabled={isExporting}
                        className="rounded-full px-8 bg-slate-900 text-white hover:bg-slate-800 font-mono font-black text-[9px] tracking-widest flex items-center gap-2 h-10 shadow-xl"
                      >
                        <Download className="w-3.5 h-3.5" />
                        {isExporting ? "EXPORTING..." : "DOWNLOAD_LAB_PDF"}
                      </Button>
                   </div>
                </div>

                {/* Main Visual Analysis */}
                {(latestScan.imageUrl || lastImageUrl) && (
                  <div className="lg:col-span-12 glass-card rounded-[3rem] p-1 shadow-2xl relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-500 z-10"></div>
                    <MultiSpectralView 
                      imageUrl={latestScan.imageUrl || lastImageUrl!} 
                      concerns={latestScan.concerns} 
                      showHotspots={showHotspots} 
                      faceMesh={latestScan.faceMesh}
                    />
                    
                    {/* Skin Age Spotlight Overlay (Top Left) */}
                    {latestScan.skinAge && (
                      <motion.div 
                        initial={{ x: -20, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.5 }}
                        className="absolute top-8 left-8 z-20 pointer-events-none hidden md:block"
                      >
                        <div className="glass-card bg-slate-900/40 backdrop-blur-xl border-white/20 p-6 rounded-[2rem] shadow-2xl flex items-center gap-6">
                          <div className="relative w-16 h-16 rounded-full border-2 border-primary/40 flex items-center justify-center">
                             <div className="absolute inset-0 bg-primary/10 rounded-full animate-pulse" />
                             <span className="text-3xl font-serif font-black italic text-white leading-none">{latestScan.skinAge.estimated}</span>
                          </div>
                          <div className="flex flex-col">
                             <span className="text-[7px] font-mono font-black text-primary uppercase tracking-[0.4em]">BIO_AGE_INDEX</span>
                             <span className="text-[11px] font-serif italic font-medium text-white/90">Visual maturity score: {latestScan.skinAge.healthScore}%</span>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    <div className="absolute top-8 right-8 flex items-center gap-3">
                         <span className="text-[8px] font-mono font-black text-white/60 tracking-widest">HUD_OVERLAY</span>
                         <Button 
                            variant="ghost" 
                            size="sm" 
                            className={cn(
                              "rounded-full h-8 px-4 transition-all duration-500 font-mono font-black text-[8px] tracking-widest",
                              showHotspots ? "bg-white text-primary shadow-lg" : "bg-black/20 text-white border border-white/10"
                            )}
                            onClick={() => setShowHotspots(!showHotspots)}
                          >
                             {showHotspots ? "ACTIVE" : "HIDDEN"}
                          </Button>
                    </div>
                  </div>
                )}

                {/* Skin Age Detailed Analysis Card */}
                {latestScan.skinAge && (
                  <div className="lg:col-span-12">
                     <SkinAgeAnalysis skinAge={latestScan.skinAge} />
                  </div>
                )}

                <div className="lg:col-span-6 glass-card rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 space-y-6 sm:space-y-8 shadow-xl border-white/40">
                          <div className="flex items-center justify-between">
                             <div className="space-y-1">
                                <h4 className="text-2xl sm:text-3xl font-serif font-black text-slate-900 italic uppercase clinical-gradient-text tracking-tighter">Biometric Radar</h4>
                                <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Multi-Spectral Sensor Balance</p>
                             </div>
                             <div className="w-10 h-10 sm:w-14 sm:h-14 rounded-[1rem] sm:rounded-[1.5rem] bg-teal-50 flex items-center justify-center border border-teal-100 shadow-sm shrink-0">
                                <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                             </div>
                          </div>
                          <SkinRadar 
                            metrics={{
                              hydration: latestScan.metrics.hydration,
                              elasticity: 100 - latestScan.metrics.aging,
                              clarity: 100 - latestScan.metrics.acne,
                              texture: latestScan.metrics.barrier,
                              resilience: 100 - latestScan.metrics.sensitivity
                            }} 
                          />
                       </div>

                       <div className="lg:col-span-6 bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 flex flex-col justify-between min-h-[400px] sm:min-h-0 space-y-8 sm:space-y-10 shadow-2xl relative overflow-hidden group">
                          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 blur-[100px] rounded-full"></div>
                          <div className="space-y-4 relative z-10">
                             <span className="text-[9px] font-mono font-black text-primary uppercase tracking-[0.4em]">Synthetic Insights</span>
                             <h4 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-black text-white leading-none uppercase italic tracking-tighter">Epidermal<br/>Equilibrium.</h4>
                             <p className="text-slate-400 text-sm sm:text-base font-medium leading-relaxed max-w-sm mt-4 sm:mt-6">
                                Optical sensors detect a controlled homeostasis in your basal layer. <span className="text-white">Hydration retention</span> shows a steady optimization trend of 4.2% since your previous baseline calibration.
                             </p>
                          </div>
                          <div className="flex gap-6 sm:gap-8 relative z-10">
                             <div className="flex flex-col gap-1">
                                <span className="text-[8px] font-mono text-slate-500 uppercase font-black tracking-widest">BIO_SYNC_HZ</span>
                                <span className="text-white font-serif italic font-black text-xl sm:text-2xl tracking-tighter">244.2</span>
                             </div>
                             <div className="w-[1px] h-10 bg-white/10"></div>
                             <div className="flex flex-col gap-1">
                                <span className="text-[8px] font-mono text-slate-500 uppercase font-black tracking-widest">LATENCY_MS</span>
                                <span className="text-white font-serif italic font-black text-xl sm:text-2xl tracking-tighter">0.02</span>
                             </div>
                          </div>
                       </div>

                     <div className="lg:col-span-12 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 sm:gap-6">
                      <MetricCard title="Sebum Control" value={100 - latestScan.metrics.acne} icon={CheckCircle2} variant="neutral" />
                      <MetricCard title="Barrier Health" value={latestScan.metrics.barrier} icon={ShieldCheck} variant="primary" />
                      <MetricCard title="Youth Index" value={100 - latestScan.metrics.aging} icon={Sparkles} variant="primary" />
                      <MetricCard title="Radiance" value={latestScan.metrics.glowIndex} icon={TrendingUp} variant="primary" />
                      <MetricCard title="Resilience" value={100 - latestScan.metrics.sensitivity} icon={ShieldAlert} variant="warning" />
                      <MetricCard title="Equilibrium" value={Math.round((latestScan.metrics.hydration + latestScan.metrics.barrier)/2)} icon={Droplet} variant="primary" />
                    </div>

                    {/* Historical Stability Trend */}
                    {scans.length > 1 && (
                      <Card className="lg:col-span-12 rounded-[3.5rem] glass-card p-10 shadow-xl border-white/40">
                        <div className="flex items-center justify-between mb-8">
                          <div className="space-y-1">
                            <h4 className="text-3xl font-serif font-black text-slate-900 italic uppercase clinical-gradient-text tracking-tighter">Stability Monitoring</h4>
                            <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Dermal Variance Over Time</p>
                          </div>
                          <TrendingUp className="w-6 h-6 text-primary/40" />
                        </div>
                        <div className="h-[200px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={[...scans].reverse()}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                              <XAxis 
                                dataKey="timestamp" 
                                tickFormatter={(val) => new Date(val).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                                fontSize={9}
                                fontStyle="italic"
                                fontWeight="bold"
                                axisLine={false}
                                tickLine={false}
                                hide
                              />
                              <YAxis domain={[0, 100]} hide />
                              <Tooltip 
                                content={({ active, payload }) => {
                                  if (active && payload && payload.length) {
                                    return (
                                      <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-white/10">
                                         <p className="text-[8px] font-mono font-black uppercase text-primary mb-1">DATA_POINT</p>
                                         <p className="text-xl font-serif font-black italic">{payload[0].value}%</p>
                                      </div>
                                    );
                                  }
                                  return null;
                                }}
                              />
                              <Line 
                                type="monotone" 
                                dataKey="overallScore" 
                                stroke="#0d9488" 
                                strokeWidth={3} 
                                dot={{ fill: '#0d9488', r: 4, strokeWidth: 2, stroke: '#fff' }}
                                activeDot={{ r: 6, strokeWidth: 0 }}
                                animationDuration={2000}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </Card>
                    )}

                    {/* Routine & Analysis Details */}
                    <div className="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
                       <div className="lg:col-span-5">
                          <Card className="rounded-[3.5rem] glass-card p-10 h-full border-white/40 shadow-xl">
                            <CardHeader className="p-0 pb-12">
                               <div className="flex justify-between items-center">
                                 <CardTitle className="text-4xl font-serif font-black italic tracking-tighter text-slate-900 uppercase">Bio Ritual</CardTitle>
                                 <Badge variant="ghost" className="font-mono text-[8px] uppercase tracking-widest text-primary/60 font-black">AI_GEN_PROTOCOL</Badge>
                               </div>
                            </CardHeader>
                            <CardContent className="p-0 space-y-12">
                              <div className="space-y-8">
                                <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20">
                                     <Sparkles className="w-5 h-5 text-primary" />
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-[9px] font-mono font-black uppercase tracking-[0.3em] text-slate-400">PHASE_01 (ASCEND)</span>
                                    <span className="text-[8px] font-mono font-bold text-primary uppercase tracking-[0.2em] mt-1">Light Optimized</span>
                                  </div>
                                </div>
                                <ul className="space-y-5">
                                  {latestScan.recommendations.morning.map((step: string, i: number) => (
                                    <li key={i} className="flex gap-4 text-sm font-medium text-slate-600 leading-tight group">
                                      <span className="flex-shrink-0 w-2 h-2 rounded-full border border-primary/30 mt-1.5 group-hover:bg-primary transition-all shadow-[0_0_8px_rgba(13,148,136,0)] group-hover:shadow-[0_0_8px_rgba(13,148,136,0.5)]"></span>
                                      {step}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                              <div className="space-y-8">
                                <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center shadow-lg">
                                     <Droplet className="w-5 h-5 text-white" />
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-[9px] font-mono font-black uppercase tracking-[0.3em] text-slate-400">PHASE_02 (DESCEND)</span>
                                    <span className="text-[8px] font-mono font-bold text-slate-500 uppercase tracking-[0.2em] mt-1">Deep Recovery</span>
                                  </div>
                                </div>
                                <ul className="space-y-5">
                                  {latestScan.recommendations.night.map((step: string, i: number) => (
                                    <li key={i} className="flex gap-4 text-sm font-medium text-slate-600 leading-tight group">
                                      <span className="flex-shrink-0 w-2 h-2 rounded-full border border-slate-300 mt-1.5 group-hover:bg-slate-900 transition-all"></span>
                                      {step}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </CardContent>
                          </Card>
                       </div>

                       <div className="lg:col-span-7 space-y-8">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {latestScan.concerns.map((concern: any, i: number) => (
                              <Card key={i} className="glass-card rounded-[2.5rem] border-white/40 hover:-translate-y-1 transition-all duration-500 overflow-hidden group shadow-sm">
                                <CardContent className="p-10 flex flex-col h-full">
                                  <div className="flex items-center justify-between mb-8">
                                    <h4 className="font-serif font-black text-3xl text-slate-900 tracking-tighter uppercase italic leading-none">{concern.type}</h4>
                                    <div className={cn(
                                      "px-4 py-1.5 rounded-full text-[9px] font-mono font-black uppercase tracking-widest border",
                                      concern.severity > 7 ? "bg-rose-50 text-rose-600 border-rose-100" : "bg-teal-50 text-primary border-teal-100"
                                    )}>
                                        LEV.0{concern.severity}
                                    </div>
                                  </div>
                                  <p className="text-slate-500 text-sm font-medium leading-relaxed mb-10 italic grow">"{concern.description}"</p>
                                  <div className="flex items-center justify-between pt-6 border-t border-slate-100/50">
                                    <div className="flex items-center gap-3">
                                       <div className="w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(13,148,136,0.3)]" />
                                       <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest">Confidence: {Math.round(concern.confidence * 100)}%</span>
                                    </div>
                                    <ChevronRight className="w-5 h-5 text-slate-200 group-hover:text-primary group-hover:translate-x-2 transition-all" />
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                       </div>
                    </div>
                  </motion.div>
                )}
          </div>
        )}

        {activeTab === 'assistant' && (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
             <div className="mb-16 space-y-4 text-center">
                <Badge variant="outline" className="px-6 py-2 rounded-full text-[9px] font-mono tracking-[0.4em] uppercase border-primary/20 text-primary glass-card shadow-sm">Neuro-Link Interface Active</Badge>
                <h2 className="text-7xl font-serif font-black tracking-tighter text-slate-900 leading-none italic uppercase clinical-gradient-text">Lab Advisory</h2>
                <p className="text-slate-400 font-serif italic text-xl">Real-time molecular consultation and diagnostic advisory.</p>
             </div>
             <div className="p-1 glass-card border-white/40 rounded-[3rem] shadow-2xl">
                <ChatAssistant />
             </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="max-w-6xl mx-auto space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
             <div className="space-y-6 text-center">
                <Badge variant="outline" className="px-6 py-2 rounded-full text-[9px] font-mono tracking-[0.4em] uppercase border-primary/20 text-primary glass-card shadow-sm">Core Laboratory Intelligence</Badge>
                <h2 className="text-8xl font-serif font-black tracking-tighter leading-none italic uppercase clinical-gradient-text">Digital Pharmacy</h2>
                <p className="text-slate-400 font-serif italic text-2xl max-w-lg mx-auto">Verify clinical efficacy against your unique biometric profile.</p>
             </div>
             <ProductAnalyzer />
          </div>
        )}
      </main>

      {/* Futuristic Clinical Footer */}
      <footer className="mt-40 border-t border-slate-100/50 pt-20 pb-16 max-w-screen-xl mx-auto px-8 relative overflow-hidden">
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 blur-[120px] rounded-full -mb-48 -mr-48"></div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-12 relative z-10">
           <div className="space-y-6">
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-primary" />
                <h1 className="text-2xl font-serif font-black tracking-tighter uppercase italic clinical-gradient-text">Aluune</h1>
              </div>
              <div className="flex flex-col gap-2 text-[8px] font-mono text-slate-400 uppercase tracking-[0.3em] font-black">
                 <div className="flex gap-4">
                    <span>BIO_NODE: SINGAPORE_S1</span>
                    <span>LATENCY: 0.002MS</span>
                    <span>UPTIME: 100%_NOMINAL</span>
                 </div>
                 <div className="flex gap-4">
                    <span>SECURITY: AES-4096_ENCRYPTED</span>
                    <span>SESSION: {user?.uid?.substring(0, 8) || 'ANON_SESSION'}</span>
                    <span>BUILD: v4.2.0-LAB</span>
                 </div>
              </div>
           </div>
           
           <div className="max-w-sm space-y-4">
              <div className="flex justify-end gap-6 text-slate-400 text-[10px] uppercase font-mono font-black tracking-widest">
                 <button className="hover:text-primary transition-colors">Documentation</button>
                 <button className="hover:text-primary transition-colors">Privacy_Protocol</button>
                 <button className="hover:text-primary transition-colors">Terms_Bio</button>
              </div>
              <p className="text-right text-[9px] font-mono font-bold text-slate-300 uppercase tracking-widest leading-relaxed">
                 AI BIOMETRIC ESTIMATE ONLY. NOT A CLINICAL DIAGNOSIS. CONSULT PROFESSIONALS FOR DERMAL ANOMALIES. ALL DATA ENCRYPTED UNDER HEALTH-SYNC PROTOCOL.
              </p>
           </div>
        </div>
      </footer>

      {/* Bottom Nav for Mobile */}
      <nav className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-2xl border-t border-slate-200 z-50 md:hidden h-24 flex items-center px-6">
        <div className="flex items-center justify-between w-full">
          {[
            { id: 'dashboard', icon: LayoutDashboard },
            { id: 'assistant', icon: Bot },
            { id: 'analyze', icon: Camera, special: true },
            { id: 'products', icon: Search },
            { id: 'home', icon: User },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300",
                item.special ? "bg-slate-900 -mt-16 w-20 h-20 shadow-xl ring-4 ring-white" : "",
                activeTab === item.id && !item.special ? "bg-slate-100 text-slate-900" : "text-slate-400"
              )}
            >
              <item.icon className={cn("w-6 h-6", item.special ? "text-white" : "")} />
            </button>
          ))}
        </div>
      </nav>
    </div>
    </MotionConfig>
  );
}

function MetricCard({ title, value, icon: Icon, variant }: { title: string; value: number; icon: any; variant: 'primary' | 'warning' | 'neutral' }) {
  const styles = {
    primary: {
      bg: 'bg-teal-50',
      text: 'text-primary',
      border: 'border-primary/20',
      progress: 'bg-primary'
    },
    warning: {
      bg: 'bg-rose-50',
      text: 'text-rose-500',
      border: 'border-rose-100',
      progress: 'bg-rose-500'
    },
    neutral: {
      bg: 'bg-slate-50',
      text: 'text-slate-400',
      border: 'border-slate-100',
      progress: 'bg-slate-400'
    }
  };

  const style = styles[variant];

  return (
    <Card className={cn("overflow-hidden glass-card rounded-[2rem] transition-all hover:-translate-y-1 shadow-sm", style.border)}>
      <CardContent className="p-6 sm:p-8 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <Icon className="w-16 h-16" />
        </div>
        <div className="flex items-center justify-between mb-6 sm:mb-8 relative z-10">
          <div className={cn("w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center border border-white/40 shadow-sm", style.bg)}>
            <Icon className={cn("w-5 h-5 sm:w-6 sm:h-6", style.text)} />
          </div>
          <span className="text-2xl sm:text-3xl font-serif font-black text-slate-900 tracking-tighter leading-none">{value}%</span>
        </div>
        <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-[0.2em] relative z-10">{title}</p>
        <div className="h-1.5 w-full bg-slate-100/50 rounded-full overflow-hidden mt-4 border border-white shadow-inner relative z-10">
           <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${value}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className={cn("h-full rounded-full", style.progress, "shadow-[0_0_8px_rgba(13,148,136,0.2)]")} 
           />
        </div>
      </CardContent>
    </Card>
  );
}
