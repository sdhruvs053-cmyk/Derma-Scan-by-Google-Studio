import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { SkinAnalysis } from './store';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function saveScan(scan: Omit<SkinAnalysis, 'id' | 'timestamp'>) {
  const userId = auth.currentUser?.uid;
  if (!userId) throw new Error("User must be logged in to save scan");

  const path = 'scans';
  try {
    const dataToSave = JSON.parse(JSON.stringify(scan));
    const docRef = await addDoc(collection(db, path), {
      ...dataToSave,
      userId,
      timestamp: serverTimestamp()
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function getUserScans() {
  const userId = auth.currentUser?.uid;
  if (!userId) return [];

  const path = 'scans';
  try {
    const q = query(
      collection(db, path), 
      where("userId", "==", userId),
      orderBy("timestamp", "desc")
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        timestamp: (data.timestamp as Timestamp)?.toDate().toISOString() || new Date().toISOString()
      } as SkinAnalysis;
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function saveChatMessage(role: 'user' | 'ai', content: string) {
  const userId = auth.currentUser?.uid;
  if (!userId) return;

  const path = 'chats';
  try {
    await addDoc(collection(db, path), {
      userId,
      role,
      content,
      timestamp: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function saveProductAnalysis(ingredients: string, analysis: any) {
  const userId = auth.currentUser?.uid;
  if (!userId) return;

  const path = 'product_analyses';
  try {
    const sanitizedAnalysis = JSON.parse(JSON.stringify(analysis));
    await addDoc(collection(db, path), {
      userId,
      ingredients,
      analysis: sanitizedAnalysis,
      timestamp: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function getChatHistory() {
  const userId = auth.currentUser?.uid;
  if (!userId) return [];

  const path = 'chats';
  try {
    const q = query(
      collection(db, path), 
      where("userId", "==", userId),
      orderBy("timestamp", "asc")
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({
      role: doc.data().role,
      content: doc.data().content
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}
