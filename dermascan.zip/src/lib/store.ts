import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SkinAnalysis {
  id: string;
  timestamp: string;
  overallScore: number;
  faceMesh?: any[];
  imageUrl?: string;
  skinAge?: {
    estimated: number;
    difference: number;
    confidence: number;
    healthScore: number;
    severityLevel: 'Low' | 'Moderate' | 'High';
    factors: {
      type: string;
      impact: number;
      description: string;
    }[];
  };
  concerns: {
    type: string;
    severity: number;
    description: string;
    confidence: number;
    locationMask?: string;
  }[];
  metrics: {
    hydration: number;
    acne: number;
    barrier: number;
    aging: number;
    glowIndex: number;
    sensitivity: number;
  };
  recommendations: {
    morning: string[];
    night: string[];
    weekly: string[];
    ingredients: {
      name: string;
      benefit: string;
    }[];
    avoid: string[];
  };
}

interface UserStore {
  user: {
    uid: string;
    name: string;
    email: string;
    skinType: string;
    concerns: string[];
  } | null;
  scans: SkinAnalysis[];
  isInitialized: boolean;
  setUser: (user: UserStore['user']) => void;
  setScans: (scans: SkinAnalysis[]) => void;
  addScan: (scan: SkinAnalysis) => void;
  setInitialized: (val: boolean) => void;
  clearHistory: () => void;
}

export const useUserStore = create<UserStore>()(
  persist(
    (set) => ({
      user: null,
      scans: [],
      isInitialized: false,
      setUser: (user) => set({ user }),
      setScans: (scans) => set({ scans }),
      addScan: (scan) => set((state) => ({ scans: [scan, ...state.scans] })),
      setInitialized: (val) => set({ isInitialized: val }),
      clearHistory: () => set({ scans: [] }),
    }),
    {
      name: 'dermascan-storage',
    }
  )
);
