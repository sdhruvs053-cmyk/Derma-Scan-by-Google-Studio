import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeSkin(imageData: string) {
  const prompt = `
    Analyze this facial skin image as a professional dermatologist assistant.
    Identify skin concerns, estimate metrics, and provide recommendations.
    
    Return a JSON object with the following structure:
    {
      "overallScore": number (0-100),
      "skinAge": {
        "estimated": number,
        "difference": number,
        "confidence": number,
        "healthScore": number,
        "severityLevel": "Low" | "Moderate" | "High",
        "factors": [
          { "type": string, "impact": number, "description": string }
        ]
      },
      "concerns": [
        {
          "type": string (e.g., "Acne", "Pigmentation", "Wrinkles", "Redness", "Oiliness"),
          "severity": number (1-10),
          "description": string,
          "confidence": number (0-1),
          "region": string (e.g., "Forehead", "Cheek", "Nose"),
          "coordinates": { "x": number, "y": number },
          "mappingData": {
             "points": { "x": number, "y": number }[], (multiple points if it's a cluster or spot group)
             "path": string, (SVG path data if it's a wrinkle line, using 0-100 coordinate space)
             "intensity": number (0-1)
          }
        }
      ],
      "metrics": {
        "hydration": number (0-100),
        "acne": number (0-100),
        "barrier": number (0-100),
        "aging": number (0-100),
        "glowIndex": number (0-100),
        "sensitivity": number (0-100)
      },
      "recommendations": {
        "morning": string[],
        "night": string[],
        "weekly": string[],
        "ingredients": [{"name": string, "benefit": string}],
        "avoid": string[]
      }
    }
    
    Be objective and avoid definitive medical diagnoses. Include a disclaimer.
  `;

  const result = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageData.split(',')[1],
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      temperature: 0.1,
    },
  });

  return JSON.parse(result.text || "{}");
}

export async function analyzeIngredients(ingredientsText: string) {
  const prompt = `
    Analyze the following skincare ingredients:
    "${ingredientsText}"
    
    Identify:
    1. Comedogenic ingredients
    2. Potential irritants
    3. Fungal acne triggers
    4. Key active benefits
    5. Overall compatibility score (0-100)
    
    Return JSON format.
  `;

  const result = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    },
  });

  return JSON.parse(result.text || "{}");
}
