import { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";
import { GoogleGenAI } from "@google/genai";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bot, User, Send, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUserStore } from "@/lib/store";
import { saveChatMessage, getChatHistory } from "@/lib/firestoreService";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export function ChatAssistant() {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollBottomRef = useRef<HTMLDivElement>(null);
  const { scans, user } = useUserStore();

  useEffect(() => {
    const loadHistory = async () => {
      if (user) {
        const history = await getChatHistory();
        if (history && history.length > 0) {
          setMessages(history);
        } else {
          setMessages([
            { role: 'ai', content: `Protocol established. Hello ${user.name}. I am your Dermal Intelligence Advisory node. Your biometric history is synced. How may I assist your optimization today?` }
          ]);
        }
      }
    };
    loadHistory();
  }, [user]);

  useEffect(() => {
    scrollBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);
    
    await saveChatMessage('user', userMsg);

    try {
      const latestScan = scans[0];
      const context = latestScan 
        ? `User's latest skin analysis: Overall score ${latestScan.overallScore}. 
           Concerns: ${latestScan.concerns.map(c => c.type).join(', ')}. 
           Metrics: Hydration ${latestScan.metrics.hydration}%, Acne ${latestScan.metrics.acne}%.`
        : "No previous skin scan results available.";

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `
              Context: ${context}
              
              Role: You are a professional skincare consultant AI assistant in a futuristic clinical laboratory. 
              Tone: Professional, intelligent, clinical, yet encouraging. Use some tech/medical terminology sparingly.
              Guidelines:
              - Reference user data if available.
              - Suggest active ingredients (e.g., Niacinamide, Retinol).
              - Keep responses concise and formatted for readability.
              
              User query: ${userMsg}
            ` }]
          }
        ],
      });

      const aiMsg = response.text || "Diagnostic error. Please restate your query.";
      setMessages(prev => [...prev, { role: 'ai', content: aiMsg }]);
      await saveChatMessage('ai', aiMsg);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', content: "Link failure. Server node unreachable. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[500px] md:h-[700px] bg-white rounded-[4rem] overflow-hidden border-8 border-white shadow-2xl relative glass-card">
      {/* HUD Header */}
      <div className="p-8 border-b border-slate-100 flex items-center justify-between relative bg-slate-50/50">
        <div className="flex items-center gap-6">
          <div className="w-14 h-14 bg-slate-900 rounded-[1.5rem] flex items-center justify-center shadow-lg relative group">
            <Bot className="w-6 h-6 text-primary group-hover:rotate-12 transition-transform" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white animate-pulse"></div>
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-serif font-black text-slate-900 tracking-tight uppercase italic clinical-gradient-text">Advisory Hub</h3>
            <p className="text-[9px] text-slate-400 font-mono font-black uppercase tracking-[0.3em]">Neural Link: STABLE_V4</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
           <div className="flex items-center gap-2">
              <span className="text-[8px] font-mono font-black text-emerald-600 uppercase">ENCRYPTED_SESSION</span>
              <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
           </div>
           <span className="text-[7px] font-mono text-slate-300 uppercase tracking-widest">Latency: 0.002ms</span>
        </div>
      </div>

      <ScrollArea className="flex-1 min-h-0 px-8 py-10 relative">
        <div className="absolute inset-0 medical-grid opacity-5 pointer-events-none"></div>
        <div className="space-y-10 relative z-10">
          {messages.map((msg, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex items-start gap-5",
                msg.role === 'user' ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border-2 shadow-sm transition-all",
                msg.role === 'ai' ? "bg-white border-emerald-100 text-emerald-600" : "bg-slate-900 border-slate-800 text-white"
              )}>
                {msg.role === 'ai' ? <Bot className="w-6 h-6" /> : <User className="w-6 h-6" />}
              </div>
              <div className={cn(
                "p-6 rounded-[2.5rem] max-w-[80%] text-[15px] leading-relaxed shadow-xl relative group",
                msg.role === 'user' 
                  ? "bg-slate-900 text-white rounded-tr-none" 
                  : "bg-white border border-slate-100 text-slate-600 rounded-tl-none font-medium italic"
              )}>
                {msg.content}
                <div className={cn(
                  "absolute bottom-0 w-8 h-[1px] bg-primary/20",
                  msg.role === 'user' ? "right-full mr-4" : "left-full ml-4"
                )}></div>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <div className="flex items-center gap-4 text-primary animate-pulse ml-16">
              <div className="flex gap-1">
                 <div className="w-1 h-3 bg-primary animate-bounce"></div>
                 <div className="w-1 h-3 bg-primary animate-bounce delay-75"></div>
                 <div className="w-1 h-3 bg-primary animate-bounce delay-150"></div>
              </div>
              <span className="text-[10px] font-mono font-black uppercase tracking-[0.4em]">SYNTHESIZING_ADVICE...</span>
            </div>
          )}
          <div ref={scrollBottomRef} />
        </div>
      </ScrollArea>

      <div className="p-8 bg-slate-50/80 backdrop-blur-xl border-t border-slate-100 relative">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          className="flex gap-4"
        >
          <div className="relative flex-1">
            <Input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Query biometric optimization protocol..."
              className="rounded-3xl bg-white border border-slate-200 h-16 pl-8 pr-20 text-slate-900 shadow-xl transition-all hover:border-primary/30 focus-visible:ring-primary/20 font-medium placeholder:text-slate-300 italic"
            />
            <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2">
               <div className="w-[1px] h-4 bg-slate-100"></div>
               <span className="text-[10px] font-mono text-slate-300 font-black uppercase tracking-widest">READY</span>
            </div>
          </div>
          <Button type="submit" disabled={isLoading} className="rounded-3xl h-16 w-16 bg-slate-900 hover:bg-slate-800 text-white shadow-2xl transition-transform hover:scale-105 active:scale-95 group">
            <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </Button>
        </form>
      </div>
    </div>
  );
}
