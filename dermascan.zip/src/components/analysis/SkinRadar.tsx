import React from 'react';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from 'recharts';

interface SkinRadarProps {
  metrics: {
    hydration: number;
    elasticity: number;
    clarity: number;
    texture: number;
    resilience: number;
  };
}

export function SkinRadar({ metrics }: SkinRadarProps) {
  const data = [
    { subject: 'HYDRATION', A: metrics.hydration, fullMark: 100 },
    { subject: 'ELASTICITY', A: metrics.elasticity, fullMark: 100 },
    { subject: 'CLARITY', A: metrics.clarity, fullMark: 100 },
    { subject: 'TEXTURE', A: metrics.texture, fullMark: 100 },
    { subject: 'RESILIENCE', A: metrics.resilience, fullMark: 100 },
  ];

  return (
    <div className="w-full h-[300px] flex items-center justify-center">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis 
            dataKey="subject" 
            tick={{ fill: '#64748b', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em' }} 
          />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="Skin Metrics"
            dataKey="A"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.2}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
