import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, TrendingDown, TrendingUp, ShieldCheck, Zap, Info, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

interface SkinAgeAnalysisProps {
  skinAge: {
    estimated: number;
    difference: number;
    confidence: number;
    healthScore: number;
    severityLevel: 'Low' | 'Moderate' | 'High';
    factors: {
      type: string;
      impact: number;
      description: string;
    }[];
  };
}

export function SkinAgeAnalysis({ skinAge }: SkinAgeAnalysisProps) {
  const isYounger = skinAge.difference < 0;
  const absDifference = Math.abs(skinAge.difference);
  const [showTarget, setShowTarget] = useState(false);

  return (
    <Card className="rounded-[3rem] glass-card border-white/40 shadow-xl overflow-hidden group relative">
      <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-teal-500 to-cyan-500 z-20"></div>
      
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/5 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <CardContent className="p-8 sm:p-10 space-y-12 relative z-10">
        {/* Header section with Age Gauge */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <div className="lg:col-span-4 flex flex-col items-center">
            <div className="relative w-56 h-56">
              {/* Pulse Ring */}
              <div className="absolute inset-0 rounded-full bg-primary/5 animate-pulse scale-110"></div>
              
              {/* Background Circle */}
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="112"
                  cy="112"
                  r="104"
                  fill="none"
                  stroke="rgba(13, 148, 136, 0.08)"
                  strokeWidth="8"
                />
                <motion.circle
                  cx="112"
                  cy="112"
                  r="104"
                  fill="none"
                  stroke="url(#ageGradient)"
                  strokeWidth="12"
                  strokeDasharray="653"
                  initial={{ strokeDashoffset: 653 }}
                  animate={{ strokeDashoffset: 653 - (653 * (skinAge.healthScore / 100)) }}
                  transition={{ duration: 2.5, ease: [0.34, 1.56, 0.64, 1] }}
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="ageGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#2dd4bf" />
                    <stop offset="50%" stopColor="#0d9488" />
                    <stop offset="100%" stopColor="#0891b2" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Age Display */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-[0.4em] mb-1">Visual Age</span>
                <div className="relative">
                  <motion.span 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-7xl font-serif font-black italic text-slate-900 tracking-tighter block leading-none"
                  >
                    {skinAge.estimated}
                  </motion.span>
                  <div className="absolute -top-2 -right-4">
                     <div className="w-2 h-2 bg-primary rounded-full animate-ping" />
                  </div>
                </div>
                <div className="flex items-center gap-1 mt-2">
                  <span className={cn(
                    "text-[10px] font-mono font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-sm border",
                    isYounger ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-rose-50 text-rose-600 border-rose-100"
                  )}>
                    {isYounger ? '-' : '+'}{absDifference}Yrs Delta
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-8">
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <span className="h-0.5 w-10 bg-primary/30"></span>
                <Badge variant="outline" className="px-4 py-1.5 bg-white text-primary border-primary/20 font-mono text-[9px] uppercase tracking-[0.2em] shadow-sm">
                  CHROMATIC_AGE_CALIBRATION
                </Badge>
              </div>
              <h3 className="text-4xl sm:text-5xl font-serif font-black italic tracking-tighter text-slate-900 uppercase clinical-gradient-text leading-[0.85]">
                Biological Synthesis
              </h3>
              <p className="text-slate-500 text-base font-medium leading-relaxed italic max-w-2xl">
                Advanced structural analysis detects microscopic indicators of elasticity lost, dermal thinning, and cumulative photo-exposure to synthesize a comprehensive biological age profile.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="glass-card p-6 rounded-3xl border border-white shadow-sm flex flex-col gap-2 group/card hover:bg-teal-50/30 transition-colors">
                <div className="flex items-center justify-between">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  <span className="text-[10px] font-mono font-black text-slate-400 font-bold">BIO_HEALTH</span>
                </div>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-serif font-black italic text-slate-900 leading-none">{skinAge.healthScore}</span>
                  <span className="text-[10px] font-mono font-bold text-slate-400 mb-1">/100</span>
                </div>
              </div>

              <div className="glass-card p-6 rounded-3xl border border-white shadow-sm flex flex-col gap-2 group/card hover:bg-amber-50/30 transition-colors">
                <div className="flex items-center justify-between">
                  <Zap className="w-5 h-5 text-amber-500" />
                  <span className="text-[10px] font-mono font-black text-slate-400 font-bold">AGING_INTENSITY</span>
                </div>
                <span className={cn(
                  "text-3xl font-serif font-black italic uppercase leading-none",
                  skinAge.severityLevel === 'Low' ? "text-emerald-600" : 
                  skinAge.severityLevel === 'Moderate' ? "text-amber-500" : "text-rose-500"
                )}>
                  {skinAge.severityLevel}
                </span>
              </div>

              <div className="glass-card p-6 rounded-3xl border border-white shadow-sm flex flex-col justify-center items-center gap-2 group/card bg-slate-900 group cursor-pointer overflow-hidden relative" onClick={() => setShowTarget(!showTarget)}>
                 <div className="absolute inset-0 bg-primary/10 translate-y-full group-hover:translate-y-0 transition-transform" />
                 <span className="text-[8px] font-mono font-black text-primary uppercase tracking-widest relative z-10">{showTarget ? "VIEW_CURRENT" : "SIMULATE_TARGET"}</span>
                 <p className="text-white font-serif italic text-xl font-black relative z-10">{showTarget ? "Scan Result" : "Optimal Peak"}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
           {/* Contributing Factors */}
           <div className="xl:col-span-7 space-y-8">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h4 className="text-2xl font-serif font-black text-slate-900 italic uppercase tracking-tighter">Structural Markers</h4>
                  <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest italic">Impact Distribution Across Epidermis</p>
                </div>
                <div className="flex items-center gap-2 bg-slate-100/50 px-3 py-1.5 rounded-full border border-slate-200/50">
                   <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                   <span className="text-[8px] font-mono font-black text-slate-500 uppercase tracking-widest">Live_Calibration</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {skinAge.factors.map((factor, i) => (
                  <div key={i} className="space-y-3 group/factor bg-white/40 p-5 rounded-[2rem] border border-white/60 hover:shadow-lg transition-all duration-500">
                    <div className="flex justify-between items-end">
                      <div className="space-y-1">
                        <span className="text-[11px] font-mono font-black text-slate-800 uppercase tracking-[0.2em] block">{factor.type}</span>
                        <p className="text-xs text-slate-500 font-medium italic leading-none">{factor.description}</p>
                      </div>
                      <div className="text-right">
                        <span className={cn(
                          "text-xl font-serif font-black italic tracking-tighter",
                          factor.impact > 60 ? "text-rose-500" : "text-primary"
                        )}>
                          {factor.impact}%
                        </span>
                      </div>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden border border-white shadow-inner relative">
                      {/* Secondary underflow track for aesthetics */}
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-[shimmer_2s_infinite]"></div>
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${factor.impact}%` }}
                        transition={{ duration: 1.5, delay: 0.2 + (i * 0.1), ease: "circOut" }}
                        className={cn(
                          "h-full rounded-full relative shadow-[0_0_10px_rgba(0,0,0,0.1)] transition-colors",
                          factor.impact > 60 ? "bg-rose-400 shadow-rose-200" : "bg-primary shadow-teal-200"
                        )}
                      >
                         <div className="absolute top-0 right-0 w-1 h-full bg-white/40" />
                      </motion.div>
                    </div>
                  </div>
                ))}
              </div>
           </div>

           {/* Visualization Side / Target Age Simulation */}
           <div className="xl:col-span-5 h-full min-h-[400px]">
              <div className="glass-card rounded-[3rem] border-white h-full relative overflow-hidden group/viz flex flex-col">
                 <div className="p-6 border-b border-white/60 flex items-center justify-between">
                    <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest">{showTarget ? "TARGET_STATE_OPTIMIZED" : "CURRENT_STATE_CAPTURED"}</span>
                    <Badge className={cn("rounded-full px-3 py-0.5 text-[8px] font-mono", showTarget ? "bg-primary" : "bg-slate-900")}>
                       {showTarget ? "TARGET 24YRS" : `EST. ${skinAge.estimated}YRS`}
                    </Badge>
                 </div>
                 <div className="flex-1 relative bg-slate-50 flex items-center justify-center p-8">
                    <AnimatePresence mode="wait">
                       {showTarget ? (
                         <motion.div 
                           key="target"
                           initial={{ opacity: 0, scale: 0.95 }}
                           animate={{ opacity: 1, scale: 1 }}
                           exit={{ opacity: 0, scale: 0.95 }}
                           className="text-center space-y-6"
                         >
                            <div className="w-32 h-32 mx-auto bg-primary/10 rounded-full flex items-center justify-center border-4 border-white shadow-2xl relative">
                               <Sparkles className="w-12 h-12 text-primary" />
                               <div className="absolute -inset-4 border border-primary/20 rounded-full animate-spin duration-[10s]"></div>
                            </div>
                            <div className="space-y-2">
                               <h5 className="text-2xl font-serif font-black italic color-primary tracking-tighter uppercase">Optimal Dermal Rebound</h5>
                               <p className="text-[11px] text-slate-500 leading-relaxed font-medium">Simulation with 100% hydration recovery, dermal thickening, and total UV-damage reversal.</p>
                            </div>
                         </motion.div>
                       ) : (
                         <motion.div 
                           key="current"
                           initial={{ opacity: 0, scale: 0.95 }}
                           animate={{ opacity: 1, scale: 1 }}
                           exit={{ opacity: 0, scale: 0.95 }}
                           className="text-center space-y-6"
                         >
                            <div className="w-32 h-32 mx-auto bg-slate-900 rounded-full flex items-center justify-center border-4 border-white shadow-2xl relative">
                               <Calendar className="w-12 h-12 text-white" />
                               <div className="absolute -inset-4 border border-slate-900/10 rounded-full animate-ping"></div>
                            </div>
                            <div className="space-y-2">
                               <h5 className="text-2xl font-serif font-black italic text-slate-900 tracking-tighter uppercase">Current Profile Status</h5>
                               <p className="text-[11px] text-slate-500 leading-relaxed font-medium">Visual indices reflect the current density and retention rates mapped during original scan.</p>
                            </div>
                         </motion.div>
                       )}
                    </AnimatePresence>
                 </div>
                 <div className="p-8 bg-slate-900 space-y-6">
                    <div className="flex justify-between items-end">
                       <div>
                          <p className="text-[8px] font-mono font-black text-primary uppercase tracking-[0.3em] mb-1">RECOMMENDED_PROTOCOL</p>
                          <h6 className="text-xl font-serif font-black italic text-white tracking-widest flex items-center gap-2">
                             <TrendingDown className="w-5 h-5 text-emerald-400" />
                             AGE_REVERSAL_V4
                          </h6>
                       </div>
                       <div className="text-right">
                          <p className="text-[8px] font-mono font-black text-slate-500 uppercase tracking-widest mb-1">PROBABILITY</p>
                          <span className="text-xl font-serif font-black italic text-white">92.4%</span>
                       </div>
                    </div>
                    <Button className="w-full h-12 rounded-2xl bg-primary text-white font-mono font-black text-[10px] tracking-[0.2em] shadow-xl shadow-primary/20 hover:scale-[1.02] transition-transform">
                       VIEW_CUSTOM_RECOVERY_ROUTINE
                    </Button>
                 </div>
              </div>
           </div>
        </div>
      </CardContent>
    </Card>
  );
}
