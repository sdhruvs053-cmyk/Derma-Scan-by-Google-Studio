import { useMemo } from 'react';
import { motion } from 'motion/react';

interface Point {
  x: number;
  y: number;
}

interface BiometricFacialMeshProps {
  landmarks: Point[] | null;
  concerns: any[];
  showHotspots: boolean;
  selectedView: number;
}

// Landmark Indices for standard face features
const FACE_CONTOURS = {
  silhouette: [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10],
  leftEye: [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33],
  rightEye: [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362],
  lips: [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 308, 324, 318, 402, 317, 14, 87, 178, 88, 95, 61],
  nose: [168, 6, 197, 195, 5, 4, 1, 19, 94, 2],
  eyebrows: [70, 63, 105, 66, 107, 336, 296, 334, 293, 300]
};

// Structural connections for that "AI network" look
const NETWORK_CONNECTIONS = [
  // Nose to eyes
  [1, 33], [1, 263], [1, 168],
  // Mouth to cheeks
  [61, 234], [291, 454],
  // Cheeks to eyes
  [234, 133], [454, 362],
  // Forehead grid
  [10, 67], [10, 297], [67, 103], [297, 332],
  // Jawline integrity
  [172, 136], [397, 365], [152, 148], [152, 377],
  // Smile lines areas
  [205, 50], [425, 280]
];

export function BiometricFacialMesh({ landmarks, concerns, showHotspots, selectedView }: BiometricFacialMeshProps) {
  // Generate a placeholder mesh if real data is missing
  const fallbackMesh = useMemo(() => {
    return Array.from({ length: 150 }).map(() => ({
      x: 20 + Math.random() * 60,
      y: 15 + Math.random() * 70
    }));
  }, []);

  const meshPoints = landmarks || fallbackMesh;

  const getPoint = (idx: number) => {
    if (!landmarks || !landmarks[idx]) return null;
    return landmarks[idx];
  };

  const renderPath = (indices: number[], color: string, width: number, opacity: number) => {
    if (!landmarks) return null;
    const points = indices.map(i => getPoint(i)).filter(Boolean) as Point[];
    if (points.length < 2) return null;

    const pathData = `M ${points[0].x} ${points[0].y} ` + 
      points.slice(1).map(p => `L ${p.x} ${p.y}`).join(' ');

    return (
      <motion.path
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity }}
        d={pathData}
        stroke={color}
        strokeWidth={width}
        fill="none"
        className="transition-all duration-700"
      />
    );
  };

  const renderScanLine = () => (
    <motion.div
      animate={{ top: ['0%', '100%', '0%'] }}
      transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
      className="absolute left-0 right-0 h-[2px] bg-primary/40 shadow-[0_0_15px_rgba(16,185,129,0.8)] z-40 pointer-events-none"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>
    </motion.div>
  );

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none">
      {renderScanLine()}
      
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="0.2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* The Digital Mesh Network */}
        <g className="opacity-30" filter="url(#glow)">
          {landmarks ? (
            <>
              {/* Main Feature Outlines */}
              {renderPath(FACE_CONTOURS.silhouette, "#10b981", 0.15, 0.6)}
              {renderPath(FACE_CONTOURS.leftEye, "#10b981", 0.1, 0.4)}
              {renderPath(FACE_CONTOURS.rightEye, "#10b981", 0.1, 0.4)}
              {renderPath(FACE_CONTOURS.lips, "#10b981", 0.1, 0.4)}
              {renderPath(FACE_CONTOURS.nose, "#10b981", 0.1, 0.4)}
              
              {/* Extra Structural Network Lines */}
              {NETWORK_CONNECTIONS.map((pair, idx) => {
                const p1 = getPoint(pair[0]);
                const p2 = getPoint(pair[1]);
                if (!p1 || !p2) return null;
                return (
                  <motion.line
                    key={idx}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.2 }}
                    x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                    stroke="#10b981"
                    strokeWidth="0.05"
                  />
                );
              })}

              {/* All Nodes */}
              {landmarks.map((p, i) => {
                // Focus on key points for visible nodes
                const isKeyPoint = i % 5 === 0;
                if (!isKeyPoint) return null;
                
                return (
                  <circle
                    key={i}
                    cx={p.x}
                    cy={p.y}
                    r={i % 20 === 0 ? 0.2 : 0.1}
                    fill={selectedView === 1 ? "white" : "#10b981"}
                    style={{ opacity: i % 10 === 0 ? 0.8 : 0.3 }}
                  />
                );
              })}
            </>
          ) : (
            // Fallback dots
            fallbackMesh.map((p, i) => (
              <circle
                key={i}
                cx={p.x}
                cy={p.y}
                r="0.15"
                fill="#10b981"
                className="animate-pulse"
              />
            ))
          )}
        </g>

        {/* Concern Hotspot Visuals */}
        {showHotspots && concerns.map((c, i) => {
          if (!c.coordinates) return null;
          
          const color = c.type.toLowerCase().includes('acne') ? '#f43f5e' : 
                        c.type.toLowerCase().includes('pigment') ? '#f59e0b' :
                        c.type.toLowerCase().includes('wrinkle') ? '#0ea5e9' : 
                        '#10b981';

          return (
            <g key={i}>
              <motion.circle
                initial={{ r: 0, opacity: 0 }}
                animate={{ r: 1.5, opacity: 0.2 }}
                cx={c.coordinates.x}
                cy={c.coordinates.y}
                fill={color}
              />
              <motion.circle
                initial={{ r: 0 }}
                animate={{ r: 2.5 }}
                transition={{ duration: 2, repeat: Infinity }}
                cx={c.coordinates.x}
                cy={c.coordinates.y}
                stroke={color}
                strokeWidth="0.1"
                fill="none"
              />
              {c.mappingData?.path && (
                <motion.path
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  d={c.mappingData.path}
                  stroke={color}
                  strokeWidth="0.4"
                  strokeDasharray="1 1"
                  fill="none"
                />
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
