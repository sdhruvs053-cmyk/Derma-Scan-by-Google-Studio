import { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import * as faceLandmarksDetection from '@tensorflow-models/face-landmarks-detection';
import '@tensorflow/tfjs-backend-webgl';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, RefreshCcw, Sparkles, ShieldCheck, Zap, Upload, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FaceScannerProps {
  onCapture: (image: string, landmarks: any[] | null) => void;
  isAnalyzing: boolean;
}

export function FaceScanner({ onCapture, isAnalyzing }: FaceScannerProps) {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [detector, setDetector] = useState<faceLandmarksDetection.FaceLandmarksDetector | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [isFaceAligned, setIsFaceAligned] = useState(false);
  const [status, setStatus] = useState('Initializing Sensors...');
  const [videoError, setVideoError] = useState<string | null>(null);
  const [showForceCapture, setShowForceCapture] = useState(false);

  // Initialize detector
  useEffect(() => {
    const init = async () => {
      try {
        const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
        const detectorConfig: faceLandmarksDetection.MediaPipeFaceMeshTfjsModelConfig = {
          runtime: 'tfjs',
          refineLandmarks: true,
          maxFaces: 1,
        };
        const newDetector = await faceLandmarksDetection.createDetector(model, detectorConfig);
        setDetector(newDetector);
        setIsReady(true);
        setStatus('Ready for Scan');
      } catch (error) {
        console.error('Detector init error:', error);
        setVideoError('Biometric logic failed to initialize. You can still upload a photo manually.');
        setStatus('Hardware Error');
      }
    };
    init();

    // Show force capture option if no face detected for 5 seconds
    const timer = setTimeout(() => {
      setShowForceCapture(true);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const onUserMediaError = useCallback(() => {
    setVideoError('Camera access denied. Biometric mapping requires optical feed. Please use manual upload.');
    setStatus('Connection Fault');
  }, []);

  const requestRef = useRef<number>(null);

  const detect = useCallback(async () => {
    if (
      detector &&
      webcamRef.current &&
      webcamRef.current.video &&
      webcamRef.current.video.readyState === 4 &&
      canvasRef.current
    ) {
      const video = webcamRef.current.video;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Only update size if changed
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      }

      const faces = await detector.estimateFaces(video, { flipHorizontal: false });

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (faces.length > 0) {
        const face = faces[0];
        const keypoints = face.keypoints;

        const box = face.box;
        const centerX = box.xMin + box.width / 2;
        const centerY = box.yMin + box.height / 2;
        const imgCenterX = canvas.width / 2;
        const imgCenterY = canvas.height / 2;
        
        const distFromCenter = Math.sqrt(Math.pow(centerX - imgCenterX, 2) + Math.pow(centerY - imgCenterY, 2));
        const isCentered = distFromCenter < 60;
        const isRightSize = box.width > canvas.width * 0.25 && box.width < canvas.width * 0.8;

        setIsFaceAligned(isCentered && isRightSize);

        if (isCentered && isRightSize) {
          setStatus('Optimal Alignment Achieved');
        } else if (!isCentered) {
          setStatus('Center Face in Frame');
        } else {
          setStatus('Adjust Distance');
        }

        drawMesh(ctx, keypoints);
        drawScanLines(ctx, canvas.width, canvas.height, Date.now());
      } else {
        setIsFaceAligned(false);
        setStatus('Locating Subject...');
      }
    }
    requestRef.current = requestAnimationFrame(detect);
  }, [detector]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(detect);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [detect]);

  const drawMesh = (ctx: CanvasRenderingContext2D, points: any[]) => {
    // Medical-grade subtle mesh
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
    ctx.lineWidth = 0.5;

    // Draw nodes
    points.forEach((p, i) => {
      if (i % 2 === 0) { // Subset for performance
        ctx.fillStyle = i % 20 === 0 ? 'rgba(16, 185, 129, 0.8)' : 'rgba(16, 185, 129, 0.3)';
        const size = i % 50 === 0 ? 1.5 : 0.8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, 2 * Math.PI);
        ctx.fill();
      }

      // Draw Connections (Simplified lattice for live view)
      if (i < points.length - 1 && i % 15 === 0) {
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(points[i + 1].x, points[i + 1].y);
        ctx.stroke();
      }
    });

    // Outer Silhouette (approximate)
    ctx.beginPath();
    [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109].forEach((idx, i) => {
      const p = points[idx];
      if (!p) return;
      if (i === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    });
    ctx.closePath();
    ctx.stroke();
  };

  const drawScanLines = (ctx: CanvasRenderingContext2D, w: number, h: number, time: number) => {
    const scanPos = (time / 20) % h;
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, scanPos);
    ctx.lineTo(w, scanPos);
    ctx.stroke();

    // Add glowing gradient to scan line
    const grad = ctx.createLinearGradient(0, scanPos - 20, 0, scanPos + 20);
    grad.addColorStop(0, 'transparent');
    grad.addColorStop(0.5, 'rgba(16, 185, 129, 0.1)');
    grad.addColorStop(1, 'transparent');
    ctx.fillStyle = grad;
    ctx.fillRect(0, scanPos - 20, w, 40);
  };

  const handleCapture = async () => {
    if (webcamRef.current && detector) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        // Run one last detection for perfect landmarks
        const video = webcamRef.current.video!;
        const faces = await detector.estimateFaces(video);
        const vw = video.videoWidth;
        const vh = video.videoHeight;
        const landmarks = faces.length > 0 ? faces[0].keypoints.map(kp => ({
          x: (kp.x / vw) * 100,
          y: (kp.y / vh) * 100,
          name: kp.name
        })) : null;
        onCapture(imageSrc, landmarks);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          // For uploaded images, we don't have real-time landmarks easily without processing,
          // but the AI can still analyze. We pass null for landmarks.
          onCapture(result, null);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="relative w-full h-[600px] md:h-full overflow-hidden bg-black rounded-[3rem]">
      <Webcam
        audio={false}
        ref={webcamRef}
        onUserMediaError={onUserMediaError}
        screenshotFormat="image/jpeg"
        className="w-full h-full object-cover opacity-60 scale-x-[-1]"
        videoConstraints={{
          facingMode: "user",
          width: 720,
          height: 1280
        }}
      />
      
      {videoError && (
        <div className="absolute inset-0 bg-slate-900 flex flex-col items-center justify-center p-12 text-center space-y-6 z-50">
          <div className="w-20 h-20 bg-rose-500/20 rounded-full flex items-center justify-center border border-rose-500/50">
             <ShieldCheck className="w-10 h-10 text-rose-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-black text-white uppercase italic">Protocol Interruption</h3>
            <p className="text-slate-400 text-sm max-w-[240px] italic">{videoError}</p>
          </div>
          <div className="flex flex-col gap-3">
             <Button onClick={() => window.location.reload()} className="rounded-xl h-12 px-8 bg-white text-slate-900 border-none font-mono font-black text-[10px] tracking-widest">REBOOT_TERMINAL</Button>
             <div className="relative">
                <input 
                  type="file" 
                  accept="image/*" 
                  className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                  onChange={handleFileUpload}
                />
                <Button variant="ghost" className="rounded-xl h-12 px-8 text-white font-mono font-black text-[10px] tracking-widest border border-white/10 w-full">MANUAL_CAPTURE_UPLOAD</Button>
             </div>
          </div>
        </div>
      )}

      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover scale-x-[-1] pointer-events-none"
      />

      {/* Futuristic Overlay UI */}
      <div className="absolute inset-0 flex flex-col pointer-events-none">
        {/* Header */}
        <div className="p-4 md:p-8 flex justify-between items-start">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Zap className="w-2.5 h-2.5 text-emerald-400 animate-pulse" />
              <span className="text-[8px] md:text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-[0.3em]">H.E.R.A SENSOR SYSTEM ACTIVE</span>
            </div>
            <h3 className="text-white font-serif italic text-xl md:text-2xl uppercase tracking-tight">Spectral Scanner</h3>
          </div>
          <div className="bg-black/40 backdrop-blur-md border border-white/10 px-3 py-1.5 md:px-4 md:py-2 rounded-xl flex items-center gap-2 md:gap-3">
             <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-red-500 animate-pulse"></div>
             <span className="text-[8px] md:text-[10px] font-mono text-white/60 tracking-widest uppercase">REC</span>
             <span className="text-[8px] md:text-[10px] font-mono text-white/40 border-l border-white/10 pl-2 md:pl-3 uppercase">882-X</span>
          </div>
        </div>

        {/* Center Guide */}
        <div className="flex-1 flex items-center justify-center relative">
          <motion.div 
            animate={{ 
              scale: isFaceAligned ? 1.05 : 1,
            }}
            className={cn(
              "w-[240px] h-[320px] md:w-[280px] md:h-[380px] border-2 rounded-[5rem] md:rounded-[6rem] flex items-center justify-center relative transition-all duration-500",
              isFaceAligned ? "border-emerald-500/60" : "border-white/20"
            )}
          >
            {/* Crosshairs */}
            <div className="absolute top-1/2 left-0 w-8 h-[1px] bg-white/20"></div>
            <div className="absolute top-1/2 right-0 w-8 h-[1px] bg-white/20"></div>
            <div className="absolute top-0 left-1/2 w-[1px] h-8 bg-white/20"></div>
            <div className="absolute bottom-0 left-1/2 w-[1px] h-8 bg-white/20"></div>
            
            {/* Corners */}
            <div className="absolute top-0 left-0 w-12 h-12 border-t-2 border-l-2 border-white/40 rounded-tl-[4rem]"></div>
            <div className="absolute top-0 right-0 w-12 h-12 border-t-2 border-r-2 border-white/40 rounded-tr-[4rem]"></div>
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-2 border-l-2 border-white/40 rounded-bl-[4rem]"></div>
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-2 border-r-2 border-white/40 rounded-br-[4rem]"></div>

            <div className="absolute inset-0 bg-emerald-500/5 animate-pulse rounded-[6rem]"></div>
          </motion.div>

          {/* Status Label */}
          <div className="absolute top-[80%] left-1/2 -translate-x-1/2 -translate-y-1/2">
             <motion.div 
               animate={{ y: [0, -5, 0] }}
               transition={{ repeat: Infinity, duration: 2 }}
               className="bg-black/60 backdrop-blur-xl border border-white/10 px-8 py-3 rounded-full flex flex-col items-center gap-1 shadow-2xl"
             >
                <span className={cn(
                  "text-[9px] font-mono font-black uppercase tracking-[0.4em]",
                  isFaceAligned ? "text-emerald-400" : "text-white/40"
                )}>
                  {status}
                </span>
                {isFaceAligned && (
                   <div className="flex gap-1 mt-1">
                      {[1,2,3,4,5].map(i => (
                        <div key={i} className="w-10 h-1 bg-emerald-500/20 rounded-full overflow-hidden">
                           <motion.div 
                             initial={{ width: 0 }}
                             animate={{ width: "100%" }}
                             transition={{ duration: 0.5, delay: i * 0.1 }}
                             className="h-full bg-emerald-500"
                           />
                        </div>
                      ))}
                   </div>
                )}
             </motion.div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 md:p-8 pb-10 md:pb-12 flex flex-col items-center gap-4 md:gap-6 pointer-events-auto">
          <div className="flex items-center gap-6 md:gap-8">
            <div className="relative pointer-events-auto">
              <input 
                type="file" 
                accept="image/*" 
                className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                onChange={handleFileUpload}
              />
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center gap-1 group shadow-xl"
              >
                <Upload className="w-5 h-5 text-white group-hover:text-primary transition-colors" />
                <span className="text-[7px] font-mono font-bold text-white uppercase tracking-widest">Upload</span>
              </motion.div>
            </div>

            {/* Capture Button */}
            <AnimatePresence>
              {(isFaceAligned || showForceCapture) && !isAnalyzing && (
                <motion.div
                  initial={{ opacity: 0, y: 20, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20, scale: 0.8 }}
                  className="flex flex-col items-center gap-2 md:gap-3 pointer-events-auto"
                >
                  <Button 
                    onClick={handleCapture}
                    className="rounded-full w-16 h-16 md:w-20 md:h-20 bg-white hover:bg-emerald-50 text-slate-900 shadow-[0_0_40px_rgba(16,185,129,0.3)] group transition-all"
                  >
                    <div className="w-12 h-12 md:w-16 md:h-16 rounded-full border-2 border-emerald-600 flex items-center justify-center transition-transform group-hover:scale-95">
                      <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-emerald-600 flex items-center justify-center">
                        <Camera className="w-5 h-5 md:w-6 md:h-6 text-white" />
                      </div>
                    </div>
                  </Button>
                  {showForceCapture && !isFaceAligned && (
                    <span className="text-[7px] font-mono font-bold text-white/40 uppercase tracking-[0.2em]">Manual Trigger Enabled</span>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Placeholder/Context for Balance */}
            <div className="w-14 h-14 rounded-2xl border border-white/5 flex flex-col items-center justify-center gap-1 opacity-20">
              <ImageIcon className="w-5 h-5 text-white" />
              <span className="text-[7px] font-mono font-bold text-white uppercase tracking-widest">Ref</span>
            </div>
          </div>

          <p className="text-[10px] font-mono text-white/30 uppercase tracking-[0.2em] max-w-xs text-center leading-relaxed">
            Ensure clear visibility of both ocular and mandibular regions for optimal biometric accuracy.
          </p>
        </div>
      </div>
    </div>
  );
}
