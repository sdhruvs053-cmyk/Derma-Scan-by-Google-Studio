import { useState } from "react";
import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ShieldCheck, AlertTriangle, ScanSearch, CheckCircle2, XCircle, TrendingUp, Droplet, AlertCircle } from "lucide-react";
import { analyzeIngredients } from "@/lib/gemini";
import { saveProductAnalysis } from "@/lib/firestoreService";
import { useUserStore } from "@/lib/store";
import { toast } from "sonner";

export function ProductAnalyzer() {
  const [ingredients, setIngredients] = useState("");
  const [analysis, setAnalysis] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useUserStore();

  const handleAnalyze = async () => {
    if (!ingredients.trim()) return;
    if (!user) {
      toast.error("Please sign in to save your analysis.");
    }
    
    setIsLoading(true);
    try {
      const result = await analyzeIngredients(ingredients);
      setAnalysis(result);
      if (user) {
        await saveProductAnalysis(ingredients, result);
        toast.success("Analysis saved to your lab!");
      }
    } catch (error) {
      toast.error("Failed to analyze ingredients.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
      <div className="xl:col-span-5 space-y-8">
        <Card className="rounded-[3.5rem] border-8 border-white bg-slate-50 relative overflow-hidden group shadow-2xl glass-card">
          <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity">
             <div className="font-serif text-[120px] font-black text-slate-900 leading-none">A</div>
          </div>
          <CardHeader className="p-10 pb-4 relative z-10">
            <Badge variant="outline" className="w-fit mb-4 px-4 py-1 rounded-full border-slate-200 text-slate-400 font-mono text-[8px] tracking-[0.3em]">INPUT_BUFFER_01</Badge>
            <CardTitle className="text-5xl font-serif font-black text-slate-900 tracking-tighter uppercase italic clinical-gradient-text">Ingredient Scan</CardTitle>
            <p className="text-xs text-slate-400 font-mono tracking-widest uppercase mt-4">Cross-referencing chemical formulations against bio-standards.</p>
          </CardHeader>
          <CardContent className="p-10 pt-6 space-y-8 relative z-10">
            <div className="relative">
               <Textarea 
                 placeholder="Paste label contents (e.g. Water, Niacinamide, Glycerin...)" 
                 className="min-h-[350px] rounded-[2.5rem] bg-white border-slate-100 text-slate-900 resize-none focus-visible:ring-primary/20 p-8 leading-relaxed font-medium placeholder:text-slate-300 shadow-xl"
                 value={ingredients}
                 onChange={(e) => setIngredients(e.target.value)}
               />
               <div className="absolute bottom-6 right-8 text-slate-200 font-mono text-[9px] tracking-[0.4em] uppercase font-black">Ready_For_Parsing</div>
            </div>
            
            <Button 
              className="w-full h-20 rounded-[2.5rem] bg-slate-900 text-white hover:bg-slate-800 font-serif italic font-black text-2xl tracking-tighter shadow-2xl group transition-all"
              onClick={handleAnalyze}
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-4">
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span className="animate-pulse">PARSING_BIO_MATRIX...</span>
                </div>
              ) : (
                <div className="flex items-center gap-4">
                   <ScanSearch className="w-6 h-6 text-primary group-hover:rotate-45 transition-transform" />
                   EXECUTE_AUDIT
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="p-8 bg-primary/5 rounded-[2.5rem] border border-primary/10 flex items-center gap-6">
           <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg border border-primary/20">
              <ShieldCheck className="w-6 h-6 text-primary" />
           </div>
           <div className="space-y-1">
              <p className="text-[10px] font-mono font-black text-primary uppercase tracking-widest leading-none">Security_Protocol</p>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">All data encrypted. Cross-referenced against 4.2M scientific research papers.</p>
           </div>
        </div>
      </div>

      <div className="xl:col-span-7 space-y-10">
        {analysis ? (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-10"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
               <Card className="md:col-span-7 rounded-[3.5rem] bg-slate-900 p-10 relative overflow-hidden shadow-2xl border-none">
                  <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none group-hover:opacity-20 transition-opacity">
                     <TrendingUp className="w-24 h-24 text-primary" />
                  </div>
                  <div className="flex flex-col h-full justify-between relative z-10 space-y-10">
                     <div className="space-y-2">
                        <span className="text-[8px] font-mono font-black text-primary uppercase tracking-[0.4em]">COMPATIBILITY_SCORE</span>
                        <h3 className="text-3xl font-serif font-black text-white tracking-tighter uppercase italic leading-none">Health Synthesis</h3>
                     </div>
                     <div className="flex items-end gap-6">
                        <div className="text-9xl font-serif font-black text-white italic tracking-tighter leading-none">{analysis.overall_compatibility_score}</div>
                        <div className="flex flex-col pb-2">
                           <span className="text-primary font-serif font-black text-4xl leading-none">%</span>
                           <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest mt-2">Optimal Range</span>
                        </div>
                     </div>
                     <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden border border-white/5 shadow-inner">
                        <motion.div 
                           initial={{ width: 0 }}
                           animate={{ width: `${analysis.overall_compatibility_score}%` }}
                           transition={{ duration: 1.5, ease: "easeOut" }}
                           className="h-full bg-primary shadow-[0_0_15px_rgba(13,148,136,0.6)]"
                        />
                     </div>
                  </div>
               </Card>

               <div className="md:col-span-5 grid grid-cols-1 gap-6">
                  <Card className="p-8 rounded-[2.5rem] border border-emerald-100 bg-white relative overflow-hidden group shadow-sm flex flex-col justify-between">
                    <CheckCircle2 className="w-10 h-10 mb-2 text-emerald-500" />
                    <div>
                       <h4 className="font-mono text-[9px] text-slate-400 uppercase tracking-widest font-black mb-1">Beneficial Agents</h4>
                       <p className="text-5xl font-serif font-black text-slate-900 tracking-tighter italic leading-none">{analysis.key_active_benefits?.length || 0}</p>
                    </div>
                  </Card>
                  <Card className="p-8 rounded-[2.5rem] border border-rose-100 bg-white relative overflow-hidden group shadow-sm flex flex-col justify-between">
                    <AlertTriangle className="w-10 h-10 mb-2 text-rose-500" />
                    <div>
                       <h4 className="font-mono text-[9px] text-slate-400 uppercase tracking-widest font-black mb-1">Dermal Triggers</h4>
                       <p className="text-5xl font-serif font-black text-slate-900 tracking-tighter italic leading-none">{analysis.potential_irritants?.length || 0}</p>
                    </div>
                  </Card>
               </div>
            </div>

            <Card className="rounded-[4rem] border-8 border-white bg-white p-12 space-y-12 shadow-2xl glass-card relative">
              <div className="absolute top-0 right-0 p-10 opacity-5 font-mono text-[80px] font-black pointer-events-none">RESULT_V4</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                 <div className="space-y-6">
                   <h4 className="text-xl font-serif font-black text-slate-900 flex items-center gap-4 uppercase italic">
                     <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center border border-emerald-200">
                        <Droplet className="w-4 h-4 text-emerald-600" />
                     </div>
                     Clinical Benefits
                   </h4>
                   <div className="grid grid-cols-1 gap-3">
                     {analysis.key_active_benefits?.map((item: string, i: number) => (
                       <motion.div 
                         initial={{ opacity: 0, x: -10 }}
                         animate={{ opacity: 1, x: 0 }}
                         transition={{ delay: i * 0.1 }}
                         key={i} 
                         className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 group hover:bg-emerald-50 transition-colors"
                       >
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                          <span className="text-[11px] font-mono font-bold text-emerald-900 uppercase tracking-widest">{item}</span>
                       </motion.div>
                     ))}
                   </div>
                 </div>

                 <div className="space-y-6">
                   <h4 className="text-xl font-serif font-black text-slate-900 flex items-center gap-4 uppercase italic">
                     <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center border border-rose-200">
                        <AlertCircle className="w-4 h-4 text-rose-600" />
                     </div>
                     Risk Assessment
                   </h4>
                   <div className="grid grid-cols-1 gap-3">
                     {analysis.potential_irritants?.map((item: string, i: number) => (
                       <motion.div 
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                          key={i} 
                          className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50/50 border border-rose-100 hover:bg-rose-50 transition-colors"
                        >
                          <div className="w-1.5 h-1.5 rounded-full bg-rose-500"></div>
                          <span className="text-[11px] font-mono font-bold text-rose-900 uppercase tracking-widest">{item}</span>
                       </motion.div>
                     ))}
                   </div>
                 </div>
              </div>

              <div className="pt-10 border-t border-slate-100/50">
                 <p className="text-slate-400 font-mono text-[9px] uppercase tracking-[0.4em] font-black text-center">INTELLIGENCE_REPORT_COMPLETE // SESSION_PERSISTED</p>
              </div>
            </Card>
          </motion.div>
        ) : (
          <div className="h-full min-h-[600px] flex flex-col items-center justify-center p-20 text-center space-y-10 border-8 border-white rounded-[4rem] bg-slate-50 shadow-inner group">
            <div className="relative">
               <div className="absolute inset-0 bg-primary/20 rounded-full blur-[80px] animate-pulse"></div>
               <div className="w-32 h-32 rounded-[2.5rem] bg-white border border-slate-100 flex items-center justify-center shadow-2xl relative z-10 group-hover:rotate-12 transition-transform duration-500">
                  <ScanSearch className="w-14 h-14 text-primary opacity-40" />
               </div>
            </div>
            <div className="space-y-3 relative z-10">
              <h3 className="text-5xl font-serif font-black text-slate-900 tracking-tighter uppercase italic leading-none">Awaiting Input</h3>
              <p className="text-slate-400 font-mono text-[10px] uppercase tracking-[0.5em] font-bold">Spectral Analysis Node: IDLE</p>
            </div>
            <p className="text-slate-400 text-sm max-w-xs font-medium leading-relaxed italic">
               Sensor grid is primed. Paste ingredient list into buffer for clinical cross-referencing.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
